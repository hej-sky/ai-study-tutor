# 助力学 · 专家包（WorkBuddy 开放平台「专家」入口）

本包是「助力学 / ai-study-tutor」的 **Agent 型专家包**，用于上传到 WorkBuddy 开放平台
「发布管理 → 专家」。它与「技能」入口的包不是同一份：技能入口要求解压第一层即 `SKILL.md`，
专家入口要求 `.codebuddy-plugin/plugin.json` + `agents/` + `avatars/` + `README.md`。

## 包内结构

```
ai-study-tutor/
├── .codebuddy-plugin/plugin.json     专家核心配置与展示信息
├── agents/ai-study-tutor.md           Agent 角色定义（指向随包 Skill）
├── avatars/expert.png               512×512 PNG 头像
├── skills/ai-study-tutor/                   完整技能包（与技能入口上架包同源）
│   ├── SKILL.md
│   ├── system-prompt.md             唯一权威提示词
│   ├── usage-guide.md
│   └── examples/                    3 个文件
└── README.md
```

## 与技能入口包的关系

`skills/ai-study-tutor/` 下的 6 个文件**逐字节复制**自同版本技能入口上架包
`ai-study-tutor-v1.5.1.zip`，头像复制自 `avatar-512.png`。两者由
`build_expert.py` 一次构建、同源派生，不存在内容补丁或第二份提示词。

构建方式（在仓库任意位置执行）：

```bash
python release/build_expert.py
```

## 关键字段口径

| 字段 | 值 | 说明 |
| --- | --- | --- |
| `expertType` | `agent` | 单角色专家，非专家团 |
| `categoryId` | `15-Education` | 平台 15 类行业分类中的「教育学习」 |
| `author.email` | 见 `plugin.json` | 取自仓库 git 提交作者邮箱，随包公开 |
| `version` | 1.5.1 | 与技能入口包、仓库版本保持一致 |

## 上传提示

1. 只上传 `ai-study-tutor-expert-v1.5.1.zip` 这一个 ZIP，不要上传 `release/` 目录。
2. 若平台仍提示「未找到 .codebuddy-plugin/plugin.json」，用 `python release/build_expert.py --flat`
   生成不带顶层目录的备用包再试。
3. 平台规则可能变动，最终以开放平台后台当前提示为准；官方文档见
   https://open.workbuddy.cn/docs/expert 。

## 项目信息

- 仓库：https://gitee.com/hejsky/ai-study-tutor
- 许可证：MIT
- 客观能力边界：见 `skills/ai-study-tutor/usage-guide.md` 末尾「附：客观能力边界」
